Screenshots created by "Screenshot" special function will be stored in this directory.
